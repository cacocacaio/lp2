package br.com.herbertrausch.domain;

public interface ComentarioRepositoryCustom {
	
	Comentario findComentarioPeloComentario(String c);

}

