package br.com.herbertrausch.domain;

public interface UsuarioRepositoryCustom {
	
	Usuario findUsuarioPeloNome(String p);

}

