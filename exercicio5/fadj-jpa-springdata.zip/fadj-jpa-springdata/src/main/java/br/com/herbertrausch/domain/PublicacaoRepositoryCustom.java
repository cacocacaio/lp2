package br.com.herbertrausch.domain;

public interface PublicacaoRepositoryCustom {
	
	Publicacao findPublicacaoPelaPagina(String p);

}

